
package caffe;
import java.sql.*;
public class Caffe {
   static String db_name="linda";
   static String user="root";
   static String pass="";
   static String hostName="localhost";
   static String db_driver="com.mysql.cj.jdbc.Driver";
    public static void main(String[] args) {
      //coonnectDB();
      //showdada();
      //inserdb();
      //updatedb();
      //deletedb();
    }
    public static Connection coonnectDB(){
    try{
        Class.forName(db_driver);
        String url="jdbc:mysql://"+hostName+"/"+db_name;
        Connection connect=DriverManager.getConnection(url,user,pass);
        return connect;
       } catch(Exception e){
         e.printStackTrace();
         System.out.print(e.getMessage());
         System.out.print("No!!!!!!!!!");
       }
       return null;
    }
    public static void showdada(){
    String sql="SELECT * FROM ggez";
    try {
        Connection c = coonnectDB();
        ResultSet rs=c.createStatement().executeQuery(sql);
        while (rs.next()){
            System.out.print(" id: "+rs.getString(1)+" fname: "+rs.getString(2)+" lname: "+rs.getString(3)+" pass "+rs.getString(4)+"\n");
        }
        } catch(Exception e){
         e.printStackTrace();
         System.out.print(e.getMessage());
         System.out.print("No!!!!!!!!!");  
    }
    }
    public static void inserdb(){
        String sql ="INSERT INTO ggez VALUES ('104','sans','567980','phyton')";
        try {
        Connection c = coonnectDB();
        Statement stm = c.createStatement();
        stm.executeUpdate(sql);
        System.out.print("it save ");
        stm.close();c.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void updatedb(){
        String sql = "UPDATE ggez set id='1',"+"name='yolo',"+"mobile='010',"+"course='c' where id='101'";
        try{
            Connection c =coonnectDB();
            Statement stm=c.createStatement();
            stm.executeUpdate(sql);
            System.out.print("it fix ");
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void deletedb(){
        String sql="delete from ggez where id = '1'";
        try{
            Connection c =coonnectDB();
            Statement stm=c.createStatement();
            stm.executeUpdate(sql);
            System.out.print("it deleted ");
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
}
