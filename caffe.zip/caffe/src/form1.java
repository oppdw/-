
import static caffe.Caffe.coonnectDB;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DateFormat;
import java.util.Date;
import java.awt.Image.*;
import java.sql.*;
import java.text.*;
import java.awt.Paint.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ImageIcon;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class form1 extends javax.swing.JFrame {

    private Connection con = null;
    private ResultSet rs = null;
    private PreparedStatement pst = null;
    String sql;
    Statement s;
    String[] data;
    DefaultTableModel model;
    
    
    
    public form1() {
        initComponents();
        con = Caffe.coonnectDB();
        data = new String[2];
        model = (DefaultTableModel)tbproduct.getModel();
        loadate();
        showDataToForm();
        showDataToForm1();
        showDataCombo();
        showDataCombo2();
        date();
    }
String Imgpath =null;
    public void showDataCombo() {
        try {
            String sql = "SELECT * FROM linda.category";
            pst = con.prepareCall(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                String name = rs.getString("catid");
                ComboBoxproduct.addItem(name);
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void showDataCombo2() {
        try {
            String sql = "SELECT * FROM linda.currency";
            pst = con.prepareCall(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                String name = rs.getString("cid");
                ComboBoxproduct2.addItem(name);
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public ImageIcon ResizeImage(String imgepath,byte[] pic)
    {
     ImageIcon myImage = null;
     if(imgepath !=null)
     {
         myImage = new ImageIcon(imgepath);
     }else{
         myImage = new ImageIcon(pic);
     }
     Image img = myImage.getImage();
     Image img2 = img.getScaledInstance(jLabel17.getWidth(), jLabel17.getHeight(),Image.SCALE_SMOOTH);
     ImageIcon image = new ImageIcon(img2);
     return image;
    }
    public void showDataToForm() {
        //String sql="SELECT * FROM linda.product";
        //String sql="SELECT productid,productname,price\n"+" FROM linda.product";
        String sql = "SELECT productid as ລະຫັດສິນຄ້າ,productname as ຊື່ສິນຄ້າ,price as ລາຄ່າ,currency as ສະກຸນເງີນ,categoryid as ລະຫັດລາຍການສິນຄ້າ ,category.catename AS ລາຍການສິນຄ້າ,product.time as ເວລາ\n" + "FROM product INNER JOIN category ON product.categoryid=category.catid";
        try {
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            /*while (rs.next()){
            System.out.print((" productid:")+rs.getString(1)+(" productname:")+rs.getString(2)+"\n");
         }*/
            tbproduct.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException ex) {
            Logger.getLogger(form1.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    public void showDataToForm1() {
     String sql ="SELECT * FROM linda.category";
        try {
            pst=con.prepareStatement(sql);
            rs=pst.executeQuery();
            tbproduct1.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (SQLException ex) {
            Logger.getLogger(form1.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbproduct = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txtpdid = new javax.swing.JTextField();
        txtpdname = new javax.swing.JTextField();
        txtpdp = new javax.swing.JTextField();
        txts = new javax.swing.JTextField();
        print = new javax.swing.JButton();
        txts1 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbproduct1 = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtpdid1 = new javax.swing.JTextField();
        txtpdname1 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbproduct2 = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtpdid2 = new javax.swing.JTextField();
        txtpdname2 = new javax.swing.JTextField();
        txtpdp1 = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        txts2 = new javax.swing.JTextField();
        txts3 = new javax.swing.JTextField();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbproduct3 = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtpdid3 = new javax.swing.JTextField();
        txtpdname3 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txttime = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        ComboBoxproduct = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        ComboBoxproduct2 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jButton18 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Database");
        setBackground(new java.awt.Color(255, 0, 102));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setForeground(new java.awt.Color(255, 0, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbproduct.setBackground(new java.awt.Color(204, 204, 204));
        tbproduct.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        tbproduct.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        tbproduct.setSelectionForeground(new java.awt.Color(153, 204, 255));
        tbproduct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbproductMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbproduct);
        if (tbproduct.getColumnModel().getColumnCount() > 0) {
            tbproduct.getColumnModel().getColumn(1).setResizable(false);
            tbproduct.getColumnModel().getColumn(2).setResizable(false);
        }

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 565, 256));

        jLabel2.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ຊື່ສິນຄ້າ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 90, 80, 60));

        txtpdid.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        txtpdid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpdidActionPerformed(evt);
            }
        });
        txtpdid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtpdidKeyReleased(evt);
            }
        });
        jPanel1.add(txtpdid, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 60, 220, 30));

        txtpdname.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        txtpdname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpdnameActionPerformed(evt);
            }
        });
        jPanel1.add(txtpdname, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 100, 220, 30));

        txtpdp.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        jPanel1.add(txtpdp, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 140, 220, 30));

        txts.setFont(new java.awt.Font("Phetsarath OT", 0, 12)); // NOI18N
        txts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsActionPerformed(evt);
            }
        });
        txts.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtsKeyReleased(evt);
            }
        });
        jPanel1.add(txts, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, 450, -1));

        print.setText("PRINT");
        print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printActionPerformed(evt);
            }
        });
        jPanel1.add(print, new org.netbeans.lib.awtextra.AbsoluteConstraints(584, 300, 400, 30));

        txts1.setFont(new java.awt.Font("Phetsarath OT", 0, 12)); // NOI18N
        txts1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txts1ActionPerformed(evt);
            }
        });
        txts1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txts1KeyReleased(evt);
            }
        });
        jPanel1.add(txts1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 270, 450, -1));

        jButton5.setText("shart name");
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 100, -1));

        jButton6.setText("shart id");
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 100, -1));

        tbproduct1.setBackground(new java.awt.Color(204, 204, 204));
        tbproduct1.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        tbproduct1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        tbproduct1.setSelectionForeground(new java.awt.Color(153, 204, 255));
        tbproduct1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbproduct1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbproduct1);
        if (tbproduct1.getColumnModel().getColumnCount() > 0) {
            tbproduct1.getColumnModel().getColumn(1).setResizable(false);
            tbproduct1.getColumnModel().getColumn(2).setResizable(false);
        }

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 565, 256));

        jLabel5.setBackground(new java.awt.Color(204, 255, 0));
        jLabel5.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("ລະຫັດປະເພດສິນຄ້າ");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 340, -1, 60));

        jLabel8.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("ຊືປະເພດສິນຄ້າ");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 380, 150, 60));

        txtpdid1.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        txtpdid1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpdid1ActionPerformed(evt);
            }
        });
        txtpdid1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtpdid1KeyReleased(evt);
            }
        });
        jPanel1.add(txtpdid1, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 350, 210, 30));

        txtpdname1.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        jPanel1.add(txtpdname1, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 390, 210, 30));

        jPanel2.setForeground(new java.awt.Color(255, 0, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tbproduct2.setBackground(new java.awt.Color(204, 204, 204));
        tbproduct2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        tbproduct2.setSelectionForeground(new java.awt.Color(153, 204, 255));
        tbproduct2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbproduct2MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbproduct2);
        if (tbproduct2.getColumnModel().getColumnCount() > 0) {
            tbproduct2.getColumnModel().getColumn(1).setResizable(false);
            tbproduct2.getColumnModel().getColumn(2).setResizable(false);
        }

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 565, 256));

        jLabel9.setBackground(new java.awt.Color(204, 255, 0));
        jLabel9.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("ລະຫັດສິນຄ້າ");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, -1, 60));

        jLabel10.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("ຊື່ສິນຄ້າ");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 90, 80, 60));

        jLabel11.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("ລາຄ່າສິນຄ້າ");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 130, -1, 60));

        txtpdid2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtpdid2KeyReleased(evt);
            }
        });
        jPanel2.add(txtpdid2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 60, 160, 30));
        jPanel2.add(txtpdname2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 100, 160, 30));
        jPanel2.add(txtpdp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 140, 160, 30));

        jButton9.setForeground(new java.awt.Color(255, 0, 0));
        jButton9.setText("DELETE");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 440, 100, -1));

        jButton10.setForeground(new java.awt.Color(255, 255, 0));
        jButton10.setText("UPDATE");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(775, 440, 100, -1));

        jButton11.setForeground(new java.awt.Color(0, 153, 51));
        jButton11.setText("CLEAR");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 440, 90, -1));

        txts2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txts2ActionPerformed(evt);
            }
        });
        txts2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txts2KeyReleased(evt);
            }
        });
        jPanel2.add(txts2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, 450, -1));

        txts3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txts3ActionPerformed(evt);
            }
        });
        txts3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txts3KeyReleased(evt);
            }
        });
        jPanel2.add(txts3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 270, 450, -1));

        jButton12.setText("shart name");
        jPanel2.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 100, -1));

        jButton13.setText("shart id");
        jPanel2.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 100, -1));

        tbproduct3.setBackground(new java.awt.Color(204, 204, 204));
        tbproduct3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        tbproduct3.setSelectionForeground(new java.awt.Color(153, 204, 255));
        tbproduct3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbproduct3MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbproduct3);
        if (tbproduct3.getColumnModel().getColumnCount() > 0) {
            tbproduct3.getColumnModel().getColumn(1).setResizable(false);
            tbproduct3.getColumnModel().getColumn(2).setResizable(false);
        }

        jPanel2.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 565, 256));

        jLabel14.setBackground(new java.awt.Color(204, 255, 0));
        jLabel14.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("ລະຫັດປະເພດສິນຄ້າ");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 340, -1, 60));

        jLabel15.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("ຊືປະເພດສິນຄ້າ");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 380, 150, 60));

        txtpdid3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtpdid3KeyReleased(evt);
            }
        });
        jPanel2.add(txtpdid3, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 350, 160, 30));
        jPanel2.add(txtpdname3, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 390, 160, 30));

        jButton2.setForeground(new java.awt.Color(255, 0, 0));
        jButton2.setText("DELETE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 270, 90, -1));

        jButton3.setForeground(new java.awt.Color(255, 255, 0));
        jButton3.setText("UPDATE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 270, 90, -1));

        jButton4.setForeground(new java.awt.Color(0, 153, 51));
        jButton4.setText("CLEAR");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 270, 100, -1));

        jButton1.setForeground(new java.awt.Color(51, 51, 255));
        jButton1.setText("SAVE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 270, 80, -1));

        jLabel6.setBackground(new java.awt.Color(153, 153, 153));
        jLabel6.setFont(new java.awt.Font("Phetsarath OT", 0, 36)); // NOI18N
        jLabel6.setText("ລາຍການສິນຄ້າ");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 10, 210, 54));

        txttime.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        txttime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttimeActionPerformed(evt);
            }
        });
        jPanel2.add(txttime, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 20, 120, 30));

        jButton7.setForeground(new java.awt.Color(51, 51, 255));
        jButton7.setText("SAVE");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 440, 70, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel13.setText("D-M-Y");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 20, -1, -1));

        jLabel4.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ລະຫັດປະເພດສິນຄ້າ");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 220, -1, 40));

        ComboBoxproduct.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        ComboBoxproduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxproductActionPerformed(evt);
            }
        });
        jPanel2.add(ComboBoxproduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 230, 220, 30));

        jLabel3.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ສະກຸນເງີນ");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 170, -1, 60));

        ComboBoxproduct2.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        ComboBoxproduct2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBoxproduct2ActionPerformed(evt);
            }
        });
        jPanel2.add(ComboBoxproduct2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 180, 220, 30));

        jLabel1.setBackground(new java.awt.Color(204, 255, 0));
        jLabel1.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ຮູບພາບ");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 490, -1, 60));

        jButton8.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        jButton8.setText("ທຳອິດ");
        jPanel2.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 580, 80, -1));

        jButton14.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        jButton14.setText("ຍ້ອນກັບ");
        jPanel2.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(673, 580, 100, -1));

        jButton15.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        jButton15.setText("ຖັດໄປ");
        jPanel2.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 580, 90, -1));

        jButton16.setFont(new java.awt.Font("Phetsarath OT", 0, 14)); // NOI18N
        jButton16.setText("ສຸດທ້າຍ");
        jPanel2.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 580, 100, -1));

        jLabel17.setBackground(new java.awt.Color(204, 204, 255));
        jLabel17.setOpaque(true);
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 470, 250, 100));

        jButton18.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton18.setText("X");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 510, 40, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\xaisomboun\\Downloads\\—Pngtree—pure watercolor gradient colorful background_964413.jpg")); // NOI18N
        jLabel7.setText("jLabel5");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(-130, -80, 1140, 750));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 620));

        jLabel16.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("ລາຄ່າສິນຄ້າ");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 130, -1, 60));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 620));

        jLabel12.setBackground(new java.awt.Color(204, 255, 0));
        jLabel12.setFont(new java.awt.Font("Phetsarath OT", 0, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("ລະຫັດສິນຄ້າ");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, -1, 60));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void tbproductMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbproductMouseClicked
        try {
            int row = tbproduct.getSelectedRow();
            String selectid = tbproduct.getValueAt(row, 0).toString();
            String sql = "SELECT * FROM linda.product where productid='" + selectid + "'";
            //String sql="SELECT * FROM linda.category where productid='"+selectid+"'";
            //System.out.print(selectid+'\n');
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add1 = rs.getString("productid");
                txtpdid.setText(add1);
                String add2 = rs.getString("productname");
                txtpdname.setText(add2);
                String add3 = rs.getString("price");
                txtpdp.setText(add3);
                String add4 = rs.getString("categoryid");
                ComboBoxproduct.setSelectedItem(add4);      
            }
        } catch (SQLException ex) {
            Logger.getLogger(form1.class.getName()).log(Level.SEVERE, null, ex);
        }
           try {
            int row = tbproduct.getSelectedRow();
            String selectid = tbproduct.getValueAt(row, 0).toString();
            String sql = "SELECT * FROM linda.currency where cid='" + selectid + "'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
               
                String add1 = rs.getString("cid");
                ComboBoxproduct2.setSelectedItem(add1);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(form1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbproductMouseClicked

       void date(){
       Date d= new Date();
       SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
       txttime.setText(s.format(d));

}
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if(checkInputs() && Imgpath != null){
        try {
            String sql = "insert into product(productid,productname,price,categoryid,time,currency)VALUES(?,?,?,?,?,?)";
            pst = con.prepareStatement(sql);
            pst.setString(1, txtpdid.getText());
            pst.setString(2, txtpdname.getText());
            pst.setString(3, txtpdp.getText());
            pst.setString(4, ComboBoxproduct.getSelectedItem().toString());
            pst.setString(5,txttime.getText());
            pst.setString(6, ComboBoxproduct2.getSelectedItem().toString());
            InputStream img = new FileInputStream(new File(Imgpath)); 
            pst.setBlob(4, img);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "ບັນທຶກແລ້ວ", "ການບັນທຶກ", JOptionPane.INFORMATION_MESSAGE);
            showDataToForm();
            showDataToForm1();
            cleardatd();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        }
        System.out.print("Image =>"+Imgpath);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtpdidKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpdidKeyReleased
        try {
            String sql = "SELECT * FROM linda.product";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                String id = rs.getNString("productid");
                if (id.equalsIgnoreCase(txtpdid.getText())) {
                    JOptionPane.showMessageDialog(this, "ລະຫັດຊ້ຳ", "ເຕື່ອນ", JOptionPane.WARNING_MESSAGE);
                    cleardatd();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtpdidKeyReleased
 
    private void txtsKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsKeyReleased
        // TODO add your handling code here:
        try {
            if (txts.getText().isEmpty()) {
                showDataToForm();
                showDataToForm1();
            } else {
                String data = txts.getText();
                String sql = "SELECT productid as ລະຫັດສິນຄ້າ,productname as ຊື່ສິນຄ້າ,price as ລາຄ່າ,currency as ສະກຸນເງີນ,categoryid as ລະຫັດລາຍການສິນຄ້າ ,category.catename AS ລາຍການສິນຄ້າ,product.time as ເວລາ\n"
                        + "From product INNER JOIN category ON product.categoryid=category.catid\n"
                        + "WHERE category.catename=?";
                pst = con.prepareStatement(sql);
                pst.setString(1, data);
                rs = pst.executeQuery();
                tbproduct.setModel(DbUtils.resultSetToTableModel(rs));
                System.out.print(sql);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }//GEN-LAST:event_txtsKeyReleased
    
    public void loadate(){
    model.getDataVector().removeAllElements();
    sql="SELECT * FROM linda.product";
    try{
    s =con.createStatement();
    rs=pst.executeQuery();
    while(rs.next()){
    data[0]=rs.getString("productid");
    data[1]=rs.getString("productname");
    data[2]=rs.getString("price");
    data[3]=rs.getString("categoryid");
    model.addRow(data);
    
    }
    s.close();
    rs.close();
    }catch(Exception e){
      System.out.print("error"+e.getMessage());
    }
    }
    
       public void loadate1(){
    model.getDataVector().removeAllElements();
    sql="SELECT * FROM linda.category";
    try{
    s =con.createStatement();
    rs=pst.executeQuery();
    while(rs.next()){
    data[0]=rs.getString("catid");
    data[1]=rs.getString("catename");
    model.addRow(data);
    
    }
    s.close();
    rs.close();
    }catch(Exception e){
      System.out.print("error"+e.getMessage());
    }
    }
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
            int row = tbproduct.getSelectedRow();
            String ida =tbproduct.getValueAt(row, 0).toString();
            sql = "delete from linda.product where productid='" + ida + "'";
         try{
            s = con.createStatement();
            s.execute(sql);
            loadate();
            JOptionPane.showMessageDialog(this, "ການລົບສຳເລັດແລ້ວ", "ການລົບ", JOptionPane.INFORMATION_MESSAGE);
            showDataToForm();
            s.close();
            showDataToForm1();
            cleardatd();
        } catch (Exception e) {
            e.printStackTrace();
        }  
    }//GEN-LAST:event_jButton2ActionPerformed

    private void printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printActionPerformed
        // TODO add your handling code here:
        MessageFormat header=new MessageFormat("ລາຍການສິນຄ້າ");
        MessageFormat footer=new MessageFormat("page{0,number,integer}");
        try {
            tbproduct.print(JTable.PrintMode.NORMAL, header, footer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_printActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        try {
            int row = tbproduct.getSelectedRow();
            String idu =tbproduct.getValueAt(row, 0).toString();
            String sql = "update linda.product set "
                    + "productid= '" + txtpdid.getText() + "' ,"
                    + "productname='" + txtpdname.getText() + "',"
                    + "price='" + txtpdp.getText() + "',"
                    + "categoryid='" + ComboBoxproduct.getSelectedItem().toString() + "',"
                    + "time='" + txttime.getText() + "',"
                    + "currency='"+ComboBoxproduct2.getSelectedItem().toString()+"'"
                    + "where productid='" + idu + "'";
            s = con.createStatement();
            s.execute(sql);
            loadate();
            JOptionPane.showMessageDialog(this, "ການແກ້ໄຂ້ສຳເລັດແລ້ວ", "ການແກ້ໄຂ້", JOptionPane.INFORMATION_MESSAGE);
            showDataToForm1();
            s.close();
            showDataToForm();
            cleardatd();
        } catch (Exception e) {
            e.printStackTrace();
        }  
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsActionPerformed

    private void ComboBoxproductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxproductActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxproductActionPerformed

    private void txts1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txts1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txts1ActionPerformed

    private void txts1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txts1KeyReleased
        // TODO add your handling code here:
        try {
            if (txts1.getText().isEmpty()) {
                showDataToForm();
                showDataToForm1();
            } else {
                String data = txts1.getText();
                String sql = "SELECT productid as ລະຫັດສິນຄ້າ,productname as ຊື່ສິນຄ້າ,price as ລາຄ່າ,currency as ສະກຸນເງີນ,categoryid as ລະຫັດລາຍການສິນຄ້າ ,category.catename AS ລາຍການສິນຄ້າ,product.time as ເວລາ\n"
                        + "FROM product INNER JOIN category ON product.categoryid=category.catid\n"
                        + "WHERE category.catid=?";
                pst = con.prepareStatement(sql);
                pst.setString(1, data);
                rs = pst.executeQuery();
                tbproduct.setModel(DbUtils.resultSetToTableModel(rs));
                System.out.print(sql);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }//GEN-LAST:event_txts1KeyReleased

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
cleardatd();       
        

// TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void tbproduct1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbproduct1MouseClicked
        // TODO add your handling code here:
         try {
            int row = tbproduct1.getSelectedRow();
            String selectid = tbproduct1.getValueAt(row, 0).toString();
            String sql = "SELECT * FROM linda.category where catid='" + selectid + "'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                String add1 = rs.getString("catid");
                txtpdid1.setText(add1);
                String add2 = rs.getString("catename");
                txtpdname1.setText(add2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(form1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tbproduct1MouseClicked

    private void txtpdid1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpdid1KeyReleased
        // TODO add your handling code here:
         try {
            String sql = "SELECT * FROM linda.category";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                String id = rs.getNString("catid");
                if (id.equalsIgnoreCase(txtpdid1.getText())) {
                    JOptionPane.showMessageDialog(this, "ລະຫັດຊ້ຳ", "ເຕື່ອນ", JOptionPane.WARNING_MESSAGE);
                    cleardatd1();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtpdid1KeyReleased

    private void tbproduct2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbproduct2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tbproduct2MouseClicked

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        int row = tbproduct1.getSelectedRow();
            String ida =tbproduct1.getValueAt(row, 0).toString();
            sql = "delete from linda.category where catid='" + ida + "'";
         try{
            s = con.createStatement();
            s.execute(sql);
            loadate();
            JOptionPane.showMessageDialog(this, "ການລົບສຳເລັດແລ້ວ", "ການລົບ", JOptionPane.INFORMATION_MESSAGE);
            showDataCombo();
            showDataToForm();
            s.close();
            showDataToForm1();
            cleardatd1();
        } catch (Exception e) {
            e.printStackTrace();
        }  
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
         try {
            int row = tbproduct1.getSelectedRow();
            String idu =tbproduct1.getValueAt(row, 0).toString();
            String sql = "update linda.category set "
                    + "catid='" + txtpdid1.getText() + "',"
                    + "catename='" + txtpdname1.getText() + "'"
                    + "where catid='" + idu + "'";
            s = con.createStatement();
            s.execute(sql);
            loadate();
            JOptionPane.showMessageDialog(this, "ການແກ້ໄຂ້ສຳເລັດແລ້ວ", "ການແກ້ໄຂ້", JOptionPane.INFORMATION_MESSAGE);
            showDataCombo();
            showDataToForm1();
            s.close();
            showDataToForm();
            cleardatd1();
        } catch (Exception e) {
            e.printStackTrace();
        }  
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        showDataCombo();
        cleardatd1();  
    }//GEN-LAST:event_jButton11ActionPerformed

    private void txts2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txts2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txts2ActionPerformed

    private void txts2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txts2KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txts2KeyReleased

    private void txts3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txts3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txts3ActionPerformed

    private void txts3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txts3KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txts3KeyReleased

    private void tbproduct3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbproduct3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tbproduct3MouseClicked

    private void txtpdid3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpdid3KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpdid3KeyReleased

    private void txtpdidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpdidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpdidActionPerformed

    private void txttimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txttimeActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "insert into linda.category(catid,catename)VALUES(?,?)";
            pst = con.prepareStatement(sql);
            pst.setString(1, txtpdid1.getText());
            pst.setString(2, txtpdname1.getText());
            pst.execute();
            JOptionPane.showMessageDialog(this, "ບັນທຶກແລ້ວ", "ການບັນທຶກ", JOptionPane.INFORMATION_MESSAGE);
            showDataCombo();
            showDataToForm();
            showDataToForm1();
            cleardatd1();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_jButton7ActionPerformed

    private void txtpdid2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpdid2KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpdid2KeyReleased

    private void ComboBoxproduct2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBoxproduct2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBoxproduct2ActionPerformed

    private void txtpdid1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpdid1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpdid1ActionPerformed

    private void txtpdnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpdnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpdnameActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        // TODO add your handling code here:
        JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.home")));
        
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.images","jpg","png");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);
        if(result == JFileChooser.APPROVE_OPTION)
        {
        File selectedFile = file.getSelectedFile();
        String path = selectedFile.getAbsolutePath();
        jLabel17.setIcon(ResizeImage(path,null));
        }
        else
        {
        System.out.println("ບໍ່ມີຮູບທີເລືອກ");
        }
        
    }//GEN-LAST:event_jButton18ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(form1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(form1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(form1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(form1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new form1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBoxproduct;
    private javax.swing.JComboBox<String> ComboBoxproduct2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JButton print;
    private javax.swing.JTable tbproduct;
    private javax.swing.JTable tbproduct1;
    private javax.swing.JTable tbproduct2;
    private javax.swing.JTable tbproduct3;
    private javax.swing.JTextField txtpdid;
    private javax.swing.JTextField txtpdid1;
    private javax.swing.JTextField txtpdid2;
    private javax.swing.JTextField txtpdid3;
    private javax.swing.JTextField txtpdname;
    private javax.swing.JTextField txtpdname1;
    private javax.swing.JTextField txtpdname2;
    private javax.swing.JTextField txtpdname3;
    private javax.swing.JTextField txtpdp;
    private javax.swing.JTextField txtpdp1;
    private javax.swing.JTextField txts;
    private javax.swing.JTextField txts1;
    private javax.swing.JTextField txts2;
    private javax.swing.JTextField txts3;
    private javax.swing.JTextField txttime;
    // End of variables declaration//GEN-END:variables

    private void cleardatd() {
        txtpdid.setText("");
        txtpdname.setText("");
        txtpdp.setText("");
        ComboBoxproduct.setSelectedIndex(0);
    }
    private void cleardatd1() {
        txtpdid1.setText("");
        txtpdname1.setText("");
        ComboBoxproduct.setSelectedIndex(0);
    }

    private boolean checkInputs() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
